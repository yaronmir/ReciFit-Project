import sys

import os
# Ensure the parent directory is in the Python path so we can import core modules 
# accurately when AWS Lambda dynamically loads 'api.user_endpoints'
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.db_manager import DbManager
from core.lambda_manager import LambdaManager
from api.food_endpoints import log_food, log_recipe
from api.recipe_endpoints import chat_recipe, save_recipe, get_cookbook, save_chat_history_endpoint, get_chat_histories_endpoint, delete_chat_history_endpoint, delete_recipe_endpoint

# Initialize DbManager outside the handler so AWS Lambda can reuse the connection
db = DbManager()

def lambda_handler(event, context):
    """
    Main Router: Directs traffic based on HTTP Method and path.
    """
    method = event.get('requestContext', {}).get('http', {}).get('method', 'GET')
    path = event.get('rawPath', '')

    # Catch-all for CORS preflight requests
    if method == 'OPTIONS':
        return LambdaManager.success_response({})

    # Route: /log-food  (POST)
    if path.endswith('/log-food') and method == 'POST':
        return log_food(event, context)

    # Route: /log-recipe (POST)
    if path.endswith('/log-recipe') and method == 'POST':
        return log_recipe(event, context)

    # Route: /chat (POST)
    if path.endswith('/chat') and method == 'POST':
        return chat_recipe(event, context)

    # Route: /chat/history (POST)
    if path.endswith('/chat/history') and method == 'POST':
        return save_chat_history_endpoint(event, context)

    # Route: /chat/history/delete (POST/DELETE)
    if path.endswith('/chat/history/delete'):
        return delete_chat_history_endpoint(event, context)

    # Route: /chat/history (GET)
    if path.endswith('/chat/history') and method == 'GET':
        return get_chat_histories_endpoint(event, context)

    # Route: /recipes/save (POST)
    if path.endswith('/recipes/save') and method == 'POST':
        return save_recipe(event, context)
        
    # Route: /recipes/delete (POST/DELETE)
    if path.endswith('/recipes/delete'):
        return delete_recipe_endpoint(event, context)

    # Route: /recipes (GET)
    if path.endswith('/recipes') and method == 'GET':
        return get_cookbook(event, context)

    # Route: /profile  (GET or POST)
    if method == 'GET':
        return get_user_profile(event, context)
    elif method == 'POST':
        return update_user_profile(event, context)
    else:
        return LambdaManager.error_response(f"Method {method} not supported", 405)


def get_user_profile(event, context):
    """Retrieves a user's profile."""
    try:
        parsed = LambdaManager.parse_event(event)
        
        user_id = parsed.get('user_id') 
        if not user_id and 'userId' in parsed['query_params']:
            user_id = parsed['query_params']['userId']
        
        if not user_id:
            return LambdaManager.error_response("Missing userId parameter or unauthorized request", 401)
            
        user_data = db.get_user(user_id)
        
        if not user_data:
            return LambdaManager.error_response("User profile not found", 404)
            
        return LambdaManager.success_response({"user": user_data})
        
    except Exception as e:
        print(f"Error in get_user_profile: {e}")
        return LambdaManager.error_response(f"Internal Server Error: {str(e)}", 500)


def update_user_profile(event, context):
    """Updates to a user's custom profile fields."""
    try:
        parsed = LambdaManager.parse_event(event)

        user_id = parsed.get('user_id') 
        if not user_id and 'userId' in parsed['body']:
            user_id = parsed['body']['userId']
            
        if not user_id:
            return LambdaManager.error_response(f"Missing userId parameter. DEBUG EVENT: {str(event)}", 401)
            
        updates = parsed['body'].get('updates', {})
        if not updates:
            return LambdaManager.error_response("No update data provided", 400)
            
        db.update_user(user_id, updates)
        
        return LambdaManager.success_response({"message": "Profile updated successfully!"})
    except Exception as e:
        print(f"Error in update_user_profile: {e}")
        return LambdaManager.error_response(f"Internal Server Error: {str(e)}", 500)
